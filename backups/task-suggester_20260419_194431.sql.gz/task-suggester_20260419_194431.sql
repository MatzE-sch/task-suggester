--
-- PostgreSQL database dump
--

\restrict xZQ62ZfeKYzKdVkwu58vwyF19UPN2liTeD3dPHPiOewsrB8mHpVu3B9A9f1hzzB

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_owner_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_dependencies DROP CONSTRAINT IF EXISTS task_dependencies_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_dependencies DROP CONSTRAINT IF EXISTS task_dependencies_depends_on_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_categories DROP CONSTRAINT IF EXISTS task_categories_task_id_fkey;
ALTER TABLE IF EXISTS ONLY public.task_categories DROP CONSTRAINT IF EXISTS task_categories_category_id_fkey;
ALTER TABLE IF EXISTS ONLY public.invite_codes DROP CONSTRAINT IF EXISTS invite_codes_used_by_fkey;
ALTER TABLE IF EXISTS ONLY public.invite_codes DROP CONSTRAINT IF EXISTS invite_codes_created_by_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_task_id_fkey;
DROP INDEX IF EXISTS public.ix_users_username;
DROP INDEX IF EXISTS public.ix_invite_codes_code;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.tasks DROP CONSTRAINT IF EXISTS tasks_pkey;
ALTER TABLE IF EXISTS ONLY public.task_dependencies DROP CONSTRAINT IF EXISTS task_dependencies_pkey;
ALTER TABLE IF EXISTS ONLY public.task_categories DROP CONSTRAINT IF EXISTS task_categories_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_codes DROP CONSTRAINT IF EXISTS invite_codes_pkey;
ALTER TABLE IF EXISTS ONLY public.invite_codes DROP CONSTRAINT IF EXISTS invite_codes_code_key;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_pkey;
ALTER TABLE IF EXISTS ONLY public.categories DROP CONSTRAINT IF EXISTS categories_name_key;
ALTER TABLE IF EXISTS ONLY public.alembic_version DROP CONSTRAINT IF EXISTS alembic_version_pkc;
ALTER TABLE IF EXISTS ONLY public.activity_logs DROP CONSTRAINT IF EXISTS activity_logs_pkey;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tasks ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.invite_codes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.categories ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.activity_logs ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP TABLE IF EXISTS public.users;
DROP SEQUENCE IF EXISTS public.tasks_id_seq;
DROP TABLE IF EXISTS public.tasks;
DROP TABLE IF EXISTS public.task_dependencies;
DROP TABLE IF EXISTS public.task_categories;
DROP SEQUENCE IF EXISTS public.invite_codes_id_seq;
DROP TABLE IF EXISTS public.invite_codes;
DROP SEQUENCE IF EXISTS public.categories_id_seq;
DROP TABLE IF EXISTS public.categories;
DROP TABLE IF EXISTS public.alembic_version;
DROP SEQUENCE IF EXISTS public.activity_logs_id_seq;
DROP TABLE IF EXISTS public.activity_logs;
DROP TYPE IF EXISTS public.taskstatus;
--
-- Name: taskstatus; Type: TYPE; Schema: public; Owner: taskuser
--

CREATE TYPE public.taskstatus AS ENUM (
    'open',
    'in_progress',
    'waiting',
    'done',
    'skipped'
);


ALTER TYPE public.taskstatus OWNER TO taskuser;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    user_id integer NOT NULL,
    task_id integer,
    action character varying(32) NOT NULL,
    category_ids json DEFAULT '[]'::json NOT NULL,
    logged_date date NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.activity_logs OWNER TO taskuser;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO taskuser;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO taskuser;

--
-- Name: categories; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.categories (
    id integer NOT NULL,
    name character varying(64) NOT NULL,
    color character varying(7) DEFAULT '#6366f1'::character varying NOT NULL,
    icon character varying(32)
);


ALTER TABLE public.categories OWNER TO taskuser;

--
-- Name: categories_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.categories_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.categories_id_seq OWNER TO taskuser;

--
-- Name: categories_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.categories_id_seq OWNED BY public.categories.id;


--
-- Name: invite_codes; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.invite_codes (
    id integer NOT NULL,
    code character varying(64) NOT NULL,
    created_by integer NOT NULL,
    used_by integer,
    created_at timestamp without time zone DEFAULT now(),
    used_at timestamp without time zone
);


ALTER TABLE public.invite_codes OWNER TO taskuser;

--
-- Name: invite_codes_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.invite_codes_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.invite_codes_id_seq OWNER TO taskuser;

--
-- Name: invite_codes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.invite_codes_id_seq OWNED BY public.invite_codes.id;


--
-- Name: task_categories; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.task_categories (
    task_id integer NOT NULL,
    category_id integer NOT NULL
);


ALTER TABLE public.task_categories OWNER TO taskuser;

--
-- Name: task_dependencies; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.task_dependencies (
    task_id integer NOT NULL,
    depends_on_id integer NOT NULL
);


ALTER TABLE public.task_dependencies OWNER TO taskuser;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.tasks (
    id integer NOT NULL,
    title character varying(256) NOT NULL,
    description text,
    status public.taskstatus DEFAULT 'open'::public.taskstatus NOT NULL,
    deadline timestamp without time zone,
    owner_id integer NOT NULL,
    created_at timestamp without time zone DEFAULT now(),
    updated_at timestamp without time zone DEFAULT now(),
    snoozed_until timestamp without time zone,
    skip_count integer DEFAULT 0 NOT NULL,
    task_type character varying(20) DEFAULT 'normal'::character varying NOT NULL,
    recurrence_days integer
);


ALTER TABLE public.tasks OWNER TO taskuser;

--
-- Name: tasks_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.tasks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.tasks_id_seq OWNER TO taskuser;

--
-- Name: tasks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.tasks_id_seq OWNED BY public.tasks.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: taskuser
--

CREATE TABLE public.users (
    id integer NOT NULL,
    username character varying(64) NOT NULL,
    hashed_password character varying(128) NOT NULL,
    created_at timestamp without time zone DEFAULT now()
);


ALTER TABLE public.users OWNER TO taskuser;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: taskuser
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.users_id_seq OWNER TO taskuser;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: taskuser
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Name: categories id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.categories ALTER COLUMN id SET DEFAULT nextval('public.categories_id_seq'::regclass);


--
-- Name: invite_codes id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.invite_codes ALTER COLUMN id SET DEFAULT nextval('public.invite_codes_id_seq'::regclass);


--
-- Name: tasks id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks ALTER COLUMN id SET DEFAULT nextval('public.tasks_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.activity_logs (id, user_id, task_id, action, category_ids, logged_date, created_at) FROM stdin;
1	1	12	done	[]	2026-04-17	2026-04-17 21:49:41.241273
2	1	5	waiting	[]	2026-04-17	2026-04-17 21:50:20.79596
3	1	11	skip	[]	2026-04-17	2026-04-17 21:53:36.50899
4	1	7	skip	[8]	2026-04-17	2026-04-17 21:55:01.1124
5	1	7	skip	[8]	2026-04-17	2026-04-17 21:55:02.237616
6	1	9	waiting	[6]	2026-04-17	2026-04-17 21:56:37.399409
7	1	11	skip	[]	2026-04-17	2026-04-17 22:27:44.539658
8	1	11	skip	[]	2026-04-17	2026-04-17 22:27:49.972017
9	1	11	skip	[]	2026-04-17	2026-04-17 22:27:50.504202
10	1	1	waiting	[]	2026-04-17	2026-04-17 22:28:02.273862
11	1	2	waiting	[7, 10]	2026-04-18	2026-04-18 14:48:36.510258
12	1	4	waiting	[8]	2026-04-18	2026-04-18 14:48:53.156949
13	1	13	waiting	[1, 6]	2026-04-18	2026-04-18 19:49:56.12102
14	1	11	done	[]	2026-04-18	2026-04-18 19:54:07.037346
15	1	16	done	[12]	2026-04-18	2026-04-18 19:55:26.308032
17	1	24	done	[]	2026-04-19	2026-04-19 10:38:50.176721
18	1	24	done	[]	2026-04-19	2026-04-19 10:38:58.495367
20	1	26	done	[2]	2026-04-19	2026-04-19 13:34:24.087432
\.


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.alembic_version (version_num) FROM stdin;
c4e91f2a8d30
\.


--
-- Data for Name: categories; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.categories (id, name, color, icon) FROM stdin;
1	hardware	#ef4444	🔧
2	software	#6366f1	💻
3	basteln	#f59e0b	🪚
4	löten	#f97316	🔩
5	3d-design	#8b5cf6	🖊️
6	3d-druck	#ec4899	🖨️
7	papierkram	#64748b	📄
8	orga	#0ea5e9	📋
9	fun	#22c55e	🎮
10	chore	#78716c	🧹
11	freunde	#f97316	👫
12	draußen	#22c55e	🌿
13	sport	#3b82f6	🏃
14	spaß	#a855f7	🎉
\.


--
-- Data for Name: invite_codes; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.invite_codes (id, code, created_by, used_by, created_at, used_at) FROM stdin;
1	c9d275aa-1724-4e0b-98ae-28d843906cec	1	2	2026-04-18 07:04:17.289181	2026-04-18 07:05:00.983732
2	e1e92263-cd55-4f75-9a57-15fa46baed72	1	\N	2026-04-18 19:53:31.179308	\N
3	0f45ca44-5c7e-4ec5-9f82-da655764352f	1	\N	2026-04-18 19:56:10.549321	\N
4	76f4520e-a2b9-4c5b-b3e5-0555de02c305	1	\N	2026-04-19 13:33:27.09575	\N
\.


--
-- Data for Name: task_categories; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.task_categories (task_id, category_id) FROM stdin;
2	7
2	10
4	8
6	10
7	8
9	6
10	5
13	1
13	6
14	14
16	12
17	1
24	14
26	2
29	14
31	2
32	5
32	8
3	14
3	12
30	2
30	1
28	14
25	2
8	8
5	10
1	10
\.


--
-- Data for Name: task_dependencies; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.task_dependencies (task_id, depends_on_id) FROM stdin;
6	5
30	31
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.tasks (id, title, description, status, deadline, owner_id, created_at, updated_at, snoozed_until, skip_count, task_type, recurrence_days) FROM stdin;
3	geo cachen	\N	open	\N	1	2026-04-17 21:45:32.473439	2026-04-17 21:45:32.473439	\N	0	normal	\N
8	kidslab minecraft kurs geld nachschauen	\N	open	\N	1	2026-04-17 21:47:21.840507	2026-04-17 21:47:21.840507	\N	0	normal	\N
10	klicker leise designen	\N	open	\N	1	2026-04-17 21:49:15.391322	2026-04-17 21:49:15.391322	\N	0	normal	\N
12	done test in liste	\N	done	\N	1	2026-04-17 21:49:39.37234	2026-04-17 21:49:41.241273	\N	0	normal	\N
7	kidslab geld gameslab nachschauen nachfragen	\N	open	\N	1	2026-04-17 21:47:00.993116	2026-04-17 21:55:02.237616	\N	2	normal	\N
9	Lu zeug 3d drucken	\N	waiting	\N	1	2026-04-17 21:48:57.944561	2026-04-17 21:56:37.399409	2026-04-18 19:56:00	0	normal	\N
5	wäsche waschen	\N	open	\N	1	2026-04-17 21:46:17.962159	2026-04-17 22:10:41.067016	2026-04-18 19:50:00	0	normal	\N
1	Müll runter bringen	\N	waiting	\N	1	2026-04-17 21:42:22.934339	2026-04-17 22:28:02.273862	2026-04-19 22:00:00	0	normal	\N
14	Matzi lieb haben	\N	open	\N	2	2026-04-18 07:05:45.872419	2026-04-18 07:05:45.872419	\N	0	normal	\N
2	Rentenversicherungs zettel	\N	waiting	\N	1	2026-04-17 21:43:39.598037	2026-04-18 14:48:36.510258	2026-04-19 22:00:00	0	normal	\N
4	friseur termin ausmachen	\N	waiting	\N	1	2026-04-17 21:45:47.235869	2026-04-18 14:48:53.156949	2026-04-20 22:00:00	0	normal	\N
6	wäsche aufhängen	\N	open	2026-04-20 00:00:00	1	2026-04-17 21:46:34.307957	2026-04-18 17:52:18.442467	\N	0	normal	\N
13	klicker basteln	\N	waiting	\N	1	2026-04-17 22:33:06.72834	2026-04-18 19:49:56.12102	2026-04-19 22:00:00	0	normal	\N
11	gpn wer kommt mit orga	\N	done	\N	1	2026-04-17 21:49:29.604118	2026-04-18 19:54:07.037346	\N	4	normal	\N
16	test grün	\N	done	\N	1	2026-04-18 19:55:23.637084	2026-04-18 19:55:26.308032	\N	0	normal	\N
17	Mesh core antenne installieren	\N	open	\N	1	2026-04-19 06:16:09.042158	2026-04-19 06:16:09.042158	\N	0	normal	\N
24	test 1d	\N	open	\N	1	2026-04-19 10:18:13.883003	2026-04-19 10:38:58.495367	2026-04-20 10:38:58.496839	0	recurring	1
25	task import	/resume               135acb0b-3a9e-4ec6-8a63-a15693fba299	open	\N	1	2026-04-19 11:55:12.767488	2026-04-19 11:55:12.767488	\N	0	normal	\N
28	When breath becomes air	hören	open	\N	1	2026-04-19 12:46:10.566468	2026-04-19 12:46:10.566468	\N	0	normal	\N
29	känguru hören	\N	open	\N	1	2026-04-19 12:46:23.718059	2026-04-19 12:46:23.718059	\N	0	normal	\N
30	Tramanzeige oberstdorf	\N	open	\N	1	2026-04-19 12:46:49.647173	2026-04-19 12:46:49.647173	\N	0	normal	\N
31	tramanzeige moby api	\N	open	\N	1	2026-04-19 12:47:33.51636	2026-04-19 12:47:33.51636	\N	0	normal	\N
32	berg relief zum anmalen raussuchen	\N	open	\N	1	2026-04-19 12:49:09.744177	2026-04-19 12:49:09.744177	\N	0	normal	\N
26	claude code am handy	\N	done	\N	1	2026-04-19 12:25:15.73927	2026-04-19 13:34:24.087432	\N	0	normal	\N
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: taskuser
--

COPY public.users (id, username, hashed_password, created_at) FROM stdin;
1	matze	$2b$12$hGBtZmMmxPgvf.mGSU4FkOwItDBZqHJ5t.g4WwFxetcXGMEIDG8OK	2026-04-17 21:41:32.544366
2	Lu	$2b$12$kA6hWWGGpK1yds5tUTT9ZuyED4CpHSqB3VIZslvHN4nqk7pIX3l4C	2026-04-18 07:05:00.648178
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 25, true);


--
-- Name: categories_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.categories_id_seq', 14, true);


--
-- Name: invite_codes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.invite_codes_id_seq', 4, true);


--
-- Name: tasks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.tasks_id_seq', 32, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: taskuser
--

SELECT pg_catalog.setval('public.users_id_seq', 2, true);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: categories categories_name_key; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_name_key UNIQUE (name);


--
-- Name: categories categories_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.categories
    ADD CONSTRAINT categories_pkey PRIMARY KEY (id);


--
-- Name: invite_codes invite_codes_code_key; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_code_key UNIQUE (code);


--
-- Name: invite_codes invite_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_pkey PRIMARY KEY (id);


--
-- Name: task_categories task_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_pkey PRIMARY KEY (task_id, category_id);


--
-- Name: task_dependencies task_dependencies_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_pkey PRIMARY KEY (task_id, depends_on_id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: ix_invite_codes_code; Type: INDEX; Schema: public; Owner: taskuser
--

CREATE INDEX ix_invite_codes_code ON public.invite_codes USING btree (code);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: taskuser
--

CREATE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: activity_logs activity_logs_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE SET NULL;


--
-- Name: activity_logs activity_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invite_codes invite_codes_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: invite_codes invite_codes_used_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.invite_codes
    ADD CONSTRAINT invite_codes_used_by_fkey FOREIGN KEY (used_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: task_categories task_categories_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.categories(id) ON DELETE CASCADE;


--
-- Name: task_categories task_categories_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_categories
    ADD CONSTRAINT task_categories_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_depends_on_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_depends_on_id_fkey FOREIGN KEY (depends_on_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: task_dependencies task_dependencies_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.task_dependencies
    ADD CONSTRAINT task_dependencies_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.tasks(id) ON DELETE CASCADE;


--
-- Name: tasks tasks_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: taskuser
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict xZQ62ZfeKYzKdVkwu58vwyF19UPN2liTeD3dPHPiOewsrB8mHpVu3B9A9f1hzzB

